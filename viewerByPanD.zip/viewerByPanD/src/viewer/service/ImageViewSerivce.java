package viewer.service;

import javafx.stage.Stage;

/**
 * Created by PanD
 * 2020/5/11 15:33
 */

public interface ImageViewSerivce {

    //打开查看图片页面
    void createImageViewStage();

}
