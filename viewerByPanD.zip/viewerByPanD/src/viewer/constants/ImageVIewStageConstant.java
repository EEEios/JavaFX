package viewer.constants;

/**
 * Created by PanD
 */

public interface ImageVIewStageConstant {

    //窗口最小尺寸
    double STAGE_MIN_WIDTH = 400;
    double STAGE_MIN_HEIGHT = 300;

    //初始化尺寸
    double STAGE_PRE_WIDTH = 800;
    double STAGE_PRE_HEIGHT = 600;
}